import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;

public class csvTest {
	static final String FILE_NAME_IN1 = "EmpresasGijón.csv";// Input1
	static final String FILE_NAME_OUT1 = "EmpresasGijón.txt";// Output1
	static final String FILE_NAME_IN2 = "EmpresasGijón.txt";// Input2
	static final String FILE_NAME_OUT2 = "EmpresasGijónBis.csv";// Output2

	public static void main(String[] args) {
		try {
			readCSV(FILE_NAME_IN1, FILE_NAME_OUT1);
			System.out.println("First part of the task done");

			writeCSV(FILE_NAME_IN2, FILE_NAME_OUT2);
			System.out.println("Second part of the task done");
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public static void readCSV(String fileNameIn, String fileNameOut) {
		try {
			Scanner sc1 = new Scanner(new FileInputStream(fileNameIn)).useDelimiter("\r\n|,");
			Formatter out = new Formatter(fileNameOut);

			out.format("%14s%13s%9s%42s%9s\n", "14", "13", "9", "42", "9");

			while (sc1.hasNext()) {
				out.format("%14s%13s%9s%42s%9s\n", sc1.next(), sc1.next(), sc1.next(), sc1.next(), sc1.next());
			}

			sc1.close();
			out.close();
		} catch (FileNotFoundException e) {

			System.err.println(e.getMessage());
		}
	}

	public static void writeCSV(String fileNameIn, String fileNameInOut) {
		try {
			Scanner in = new Scanner(new FileInputStream(fileNameIn));
			Formatter out = new Formatter(fileNameInOut);
			String line, subString1, subString2, subString3, subString4, subString5 = null;
			in.nextLine();
			while (in.hasNext()) {

				line = in.nextLine();
				subString1 = treatBlanks(line.substring(0, 15));
				subString2 = treatBlanks(line.substring(15, 28));
				subString3 = treatBlanks(line.substring(28, 37));
				subString4 = treatBlanks(line.substring(37, 79));
				subString5 = treatBlanks(line.substring(79, 87));

				out.format("%s;%s;%s;%s;%s\n", subString1, subString2, subString3, subString4, subString5);
			}
			in.close();
			out.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	/**
	 * Removes blank spaces from a string.
	 * The spaces consecutive and internal next to non blank characters are
	 * substituted by a '_'.
	 * This algorithm is coded using techniques based on automata theory
	 * 
	 * @param s a string with blank spaces
	 * @return another string without blank spaces as prefix or suffix, and the
	 *         internal ones
	 *         are substituted by a '_'
	 */
	public static String treatBlanks(String s) {
		String output = "";
		int state = 0;
		char c;
		for (int i = 0; i < s.length(); i++) {
			c = s.charAt(i);
			switch (state) {
				case 0:
					if (c != ' ') {
						output = output + c;
						state = 1;
					}
					break;
				case 1:
					if (c != ' ')
						output = output + c;
					else
						state = 2;
					break;
				case 2:
					if (c != ' ') {
						output = output + '_' + c;
						state = 1;
					}
			}
		}
		return output;

	}

}
