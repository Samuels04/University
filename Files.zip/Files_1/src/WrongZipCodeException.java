public class WrongZipCodeException extends RuntimeException {
	public String getMessage() {
		return "Only Zip codes starting with 33 are accepted for Gijon";
	}

	public WrongZipCodeException() {
	}

	public StackTraceElement[] getStackTrace() {
		return super.getStackTrace();
	}
}
