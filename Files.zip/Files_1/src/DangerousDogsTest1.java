import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class DangerousDogsTest1 {
	public static void main(String[] args) throws WrongZipCodeException {
		Scanner in = null;
		String filename = "censoPerrosPeligrosos.txt";

		try {
			in = new Scanner(new FileInputStream(filename));
			String[] headers = { "BREED", "SIZE", "ZIP C.", "DISTRICT", "AMOUNT" };

			System.out.printf("%-33s%-10s%-7s%-25s%-3s\n\n", headers[0], headers[1], headers[2], headers[3],
					headers[4]);

			String breed = null;
			String size = null;
			String ZC = null;
			String Dist = null;
			int amount = 0;

			int amountSmall = 0;
			int amountBig = 0;
			int amountMedium = 0;
			while (in.hasNext()) {

				breed = in.next();
				size = in.next();
				ZC = in.next();
				Dist = in.next();
				amount = in.nextInt();

				System.out.printf("%-33s%-10s%-7s%-25s%3d\n", breed, size, ZC, Dist,
						amount);

				if (size.equals("Grande"))
					amountBig += amount;
				else if (size.equals("Mediano"))
					amountMedium += amount;
				else if (size.equals("Peque�o"))
					amountSmall += amount;

			}
			System.out.printf("There's %d small dogs, %d medium-size dogs & %d big dogs", amountSmall, amountMedium,
					amountBig);
		} catch (IOException e) {
			System.err.println(e.getMessage());

		} catch (WrongZipCodeException f) {
			System.out.println(f.getMessage());
		} finally {
			if (in != null)
				in.close();

		}
	}

	/*
	 * private static void print(Object o) {
	 * System.out.println(o.toString());
	 * }
	 */

}
